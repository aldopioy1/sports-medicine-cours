// الوظائف العامة للموقع
document.addEventListener('DOMContentLoaded', function() {
    // تفعيل التلميحات
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    });

    // تفعيل النوافذ المنبثقة
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl)
    });

    // تحقق من كلمة المرور
    const passwordField = document.getElementById('password');
    const confirmPasswordField = document.getElementById('confirm_password');
    const passwordFeedback = document.getElementById('password-feedback');

    if (passwordField && confirmPasswordField) {
        confirmPasswordField.addEventListener('input', function() {
            if (passwordField.value !== confirmPasswordField.value) {
                confirmPasswordField.setCustomValidity('كلمات المرور غير متطابقة');
                if (passwordFeedback) {
                    passwordFeedback.textContent = 'كلمات المرور غير متطابقة';
                    passwordFeedback.style.display = 'block';
                }
            } else {
                confirmPasswordField.setCustomValidity('');
                if (passwordFeedback) {
                    passwordFeedback.style.display = 'none';
                }
            }
        });
    }

    // التحقق من النموذج
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // إخفاء رسائل التنبيه تلقائياً بعد 5 ثوانٍ
    const alerts = document.querySelectorAll('.alert:not(.alert-permanent)');
    alerts.forEach(alert => {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // تفعيل العد التنازلي للتسجيل
    const countdownElement = document.getElementById('registration-countdown');
    if (countdownElement) {
        const endDate = new Date(countdownElement.getAttribute('data-end-date'));
        
        function updateCountdown() {
            const now = new Date();
            const distance = endDate - now;
            
            if (distance < 0) {
                countdownElement.innerHTML = 'انتهى التسجيل';
                return;
            }
            
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);
            
            countdownElement.innerHTML = `${days} يوم ${hours} ساعة ${minutes} دقيقة ${seconds} ثانية`;
        }
        
        updateCountdown();
        setInterval(updateCountdown, 1000);
    }

    // تفعيل حساب السعر في نموذج التسجيل
    const attendanceTypeSelect = document.getElementById('attendance_type');
    const priceElement = document.getElementById('course-price');
    const totalPriceElement = document.getElementById('total-price');
    const discountCodeInput = document.getElementById('discount_code');
    const applyDiscountButton = document.getElementById('apply-discount');
    
    if (attendanceTypeSelect && priceElement && totalPriceElement) {
        const basePrice = parseFloat(priceElement.getAttribute('data-price'));
        
        function updatePrice() {
            let price = basePrice;
            const attendanceType = attendanceTypeSelect.value;
            
            if (attendanceType === 'remote') {
                price = basePrice * 0.8; // خصم 20% للحضور عن بعد
            } else if (attendanceType === 'hybrid') {
                price = basePrice * 0.9; // خصم 10% للحضور المختلط
            }
            
            totalPriceElement.textContent = price.toFixed(2) + ' ريال';
        }
        
        attendanceTypeSelect.addEventListener('change', updatePrice);
        updatePrice();
        
        // تطبيق كود الخصم
        if (applyDiscountButton && discountCodeInput) {
            applyDiscountButton.addEventListener('click', function() {
                const discountCode = discountCodeInput.value.trim();
                
                if (discountCode === 'EARLY25') {
                    const currentPrice = parseFloat(totalPriceElement.textContent);
                    const discountedPrice = currentPrice * 0.75; // خصم 25%
                    totalPriceElement.textContent = discountedPrice.toFixed(2) + ' ريال';
                    
                    const discountFeedback = document.getElementById('discount-feedback');
                    if (discountFeedback) {
                        discountFeedback.textContent = 'تم تطبيق الخصم بنجاح!';
                        discountFeedback.className = 'text-success';
                    }
                } else {
                    const discountFeedback = document.getElementById('discount-feedback');
                    if (discountFeedback) {
                        discountFeedback.textContent = 'كود الخصم غير صالح';
                        discountFeedback.className = 'text-danger';
                    }
                }
            });
        }
    }

    // تفعيل الخريطة في صفحة الاتصال
    const mapElement = document.getElementById('contact-map');
    if (mapElement) {
        // هنا يمكن إضافة كود لتفعيل الخريطة باستخدام Google Maps API أو Leaflet
        // هذا مجرد مثال بسيط
        mapElement.innerHTML = '<div class="bg-secondary text-white p-5 text-center">هنا ستظهر الخريطة</div>';
    }
});

// وظائف لوحة التحكم
function confirmDelete(formId) {
    if (confirm('هل أنت متأكد من رغبتك في الحذف؟')) {
        document.getElementById(formId).submit();
    }
}

// وظيفة معاينة الصورة قبل الرفع
function previewImage(input, previewId) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById(previewId).src = e.target.result;
        }
        
        reader.readAsDataURL(input.files[0]);
    }
}

// وظيفة البحث في الجدول
function searchTable(inputId, tableId) {
    const input = document.getElementById(inputId);
    const filter = input.value.toUpperCase();
    const table = document.getElementById(tableId);
    const rows = table.getElementsByTagName('tr');
    
    for (let i = 1; i < rows.length; i++) {
        let found = false;
        const cells = rows[i].getElementsByTagName('td');
        
        for (let j = 0; j < cells.length; j++) {
            const cell = cells[j];
            if (cell) {
                const textValue = cell.textContent || cell.innerText;
                if (textValue.toUpperCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
        }
        
        rows[i].style.display = found ? '' : 'none';
    }
}

// وظيفة الفرز في الجدول
function sortTable(tableId, columnIndex) {
    const table = document.getElementById(tableId);
    let switching = true;
    let direction = 'asc';
    let switchcount = 0;
    
    while (switching) {
        switching = false;
        const rows = table.rows;
        
        for (let i = 1; i < (rows.length - 1); i++) {
            let shouldSwitch = false;
            const x = rows[i].getElementsByTagName('td')[columnIndex];
            const y = rows[i + 1].getElementsByTagName('td')[columnIndex];
            
            if (direction === 'asc') {
                if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
                    shouldSwitch = true;
                    break;
                }
            } else {
                if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {
                    shouldSwitch = true;
                    break;
                }
            }
            
            if (shouldSwitch) {
                rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                switching = true;
                switchcount++;
            }
        }
        
        if (switchcount === 0 && direction === 'asc') {
            direction = 'desc';
            switching = true;
        }
    }
}
