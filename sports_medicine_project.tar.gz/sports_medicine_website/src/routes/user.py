from flask import Blueprint, render_template, redirect, url_for, request, flash, session
from src.models.user import db, User
from werkzeug.security import generate_password_hash, check_password_hash

user_bp = Blueprint('user', __name__)

@user_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # التحقق من البيانات
        if not first_name or not last_name or not email or not password:
            flash('جميع الحقول مطلوبة', 'danger')
            return render_template('register.html')
            
        if password != confirm_password:
            flash('كلمات المرور غير متطابقة', 'danger')
            return render_template('register.html')
            
        # التحقق من وجود المستخدم
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash('البريد الإلكتروني مستخدم بالفعل', 'danger')
            return render_template('register.html')
            
        # إنشاء مستخدم جديد
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password=generate_password_hash(password)
        )
        
        try:
            db.session.add(new_user)
            db.session.commit()
            flash('تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول', 'success')
            return redirect(url_for('user.login'))
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء إنشاء الحساب', 'danger')
            
    return render_template('register.html')

@user_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        if not email or not password:
            flash('جميع الحقول مطلوبة', 'danger')
            return render_template('login.html')
            
        user = User.query.filter_by(email=email).first()
        
        if not user or not check_password_hash(user.password, password):
            flash('البريد الإلكتروني أو كلمة المرور غير صحيحة', 'danger')
            return render_template('login.html')
            
        session['user_id'] = user.id
        session['is_admin'] = user.is_admin
        
        if user.is_admin:
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('user.dashboard'))
            
    return render_template('login.html')

@user_bp.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('is_admin', None)
    flash('تم تسجيل الخروج بنجاح', 'success')
    return redirect(url_for('home'))

@user_bp.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول للوصول إلى لوحة التحكم', 'warning')
        return redirect(url_for('user.login'))
        
    user = User.query.get(session['user_id'])
    if not user:
        session.pop('user_id', None)
        session.pop('is_admin', None)
        flash('حدث خطأ في الحساب', 'danger')
        return redirect(url_for('user.login'))
        
    return render_template('user_dashboard.html', user=user)

@user_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    if 'user_id' not in session:
        flash('يرجى تسجيل الدخول للوصول إلى الملف الشخصي', 'warning')
        return redirect(url_for('user.login'))
        
    user = User.query.get(session['user_id'])
    
    if request.method == 'POST':
        user.first_name = request.form.get('first_name')
        user.last_name = request.form.get('last_name')
        user.phone = request.form.get('phone')
        user.date_of_birth = request.form.get('date_of_birth')
        user.gender = request.form.get('gender')
        user.nationality = request.form.get('nationality')
        user.id_number = request.form.get('id_number')
        user.address = request.form.get('address')
        user.qualification = request.form.get('qualification')
        user.specialization = request.form.get('specialization')
        user.workplace = request.form.get('workplace')
        user.job_title = request.form.get('job_title')
        user.experience_years = request.form.get('experience_years')
        
        try:
            db.session.commit()
            flash('تم تحديث الملف الشخصي بنجاح', 'success')
        except Exception as e:
            db.session.rollback()
            flash('حدث خطأ أثناء تحديث الملف الشخصي', 'danger')
            
    return render_template('profile.html', user=user)
